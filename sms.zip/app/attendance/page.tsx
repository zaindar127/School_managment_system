import { AttendanceTracker } from "@/components/attendance-tracker"

export default function AttendancePage() {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Attendance</h1>
      <AttendanceTracker />
    </div>
  )
}
